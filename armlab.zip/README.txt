We use the matplotlib library to automatically display the image when executing 
our script. If the picture does not automatically display for you, then it is 
also included in our pdf submission.

An important note is that it does take about 15-20 seconds for our config space
script to run. Please be patient.